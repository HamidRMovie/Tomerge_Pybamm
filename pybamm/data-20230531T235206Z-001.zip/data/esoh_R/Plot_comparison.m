clear 
close all

set(groot,'defaultAxesXGrid','on')
set(groot,'defaultAxesYGrid','on')
%%
colorsd=[]
cells=[       "aging_param_cell_disonly_may20_Andrew15032.csv"...
    "aging_param_cell_disonly_may20_GMJuly091.csv", "aging_param_cell_disonly_may20_GMJuly019.csv",...
       "aging_param_cell_disonly_may20_GMJuly039.csv", 
       ];
    % "aging_param_cell_disonly_may25_cell093.csv", "aging_param_cell_disonly_may25_cell087.csv",...
    % "aging_param_cell_disonly_may25_cell056.csv"];
for i=1:4
    data=[];day=[]; C=[]; Cn=[]; Cp=[]; x100=[]; y0=[];
    data=readmatrix(cells{i});
    day=data(:,1);
    C=data(:,8);
    Cn=data(:,6);
    Cp=data(:,7);
    x100=data(:,4); y0=data(:,3);
    error=data(:,11);
    C(error>10)=NaN;Cp(error>10)=NaN; Cn(error>10)=NaN;
    x100(error>10)=NaN; y0(error>10)=NaN;
    
xlabel("days")
    figure(1); hold on; plot(day, C/C(1),LineWidth=2); title("Capacity retention %");legend("Andrew SOC=100",  "GM SOC=100", "GM SC=80",  "GM SOC= 50");
    xlabel("days")
    figure(2); hold on; plot(day, Cn/Cn(1),LineWidth=2); title("Cn");legend("Andrew SOC=100",  "GM SOC=100", "GM SC=80",  "GM SOC= 50"); 
    xlabel("days")
     ylim([0.6,1.01])
    figure(3); hold on; plot(day, Cp/Cp(1),LineWidth=2); title("Cp");legend("Andrew SOC=100",  "GM SOC=100", "GM SC=80",  "GM SOC= 50");  
    xlabel("days"); ylim([0.6,1.01])
    figure(4); hold on; plot(day, x100,LineWidth=2); title("x100");legend("Andrew SOC=100",  "GM SOC=100", "GM SC=80",  "GM SOC= 50"); xlabel("days")

    figure(5); hold on; plot(day, y0,LineWidth=2); title("y0");legend("Andrew SOC=100",  "GM SOC=100", "GM SC=80",  "GM SOC= 50"); xlabel("days")

    % 



end

%% 
% load("agingparamcell152032.mat");
% 
%     data=[];day=[]; C=[]; Cn=[]; Cp=[]; x100=[]; y0=[];
%     data=agingparamcell152032;
%     day=data(:,1);
%     C=data(:,8);
%     Cn=data(:,6);
%     Cp=data(:,7);
%     x100=data(:,4); y0=data(:,3);
    % 
    % figure(1); hold on; plot(day, C/C(1),"k--",LineWidth=2);legend("SOC=100",  "80", "50",  "Andrew 90%");
    % 
    % figure(2); hold on; plot(day, Cn/Cn(1),"k--",LineWidth=2); legend("SOC=100",  "80", "50",  "Andrew 90%");
    % figure(3); hold on; plot(day, Cp/Cp(1),"k--",LineWidth=2); legend("SOC=100",  "80", "50",  "Andrew 90%");
    % figure(4); hold on; plot(day, x100,"k--",LineWidth=2); legend("SOC=100",  "80", "50",  "Andrew 90%");
    % figure(5); hold on; plot(day, y0,"k--",LineWidth=2); legend("SOC=100",  "80", "50",  "Andrew 90%");



